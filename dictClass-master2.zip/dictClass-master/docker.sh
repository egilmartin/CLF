docker build -t kyusonglee/dictclass .
docker push kyusonglee/dictclass
